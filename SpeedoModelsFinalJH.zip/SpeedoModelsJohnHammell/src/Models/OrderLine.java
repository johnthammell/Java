/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author John Hammell
 */
public class OrderLine {
    //prv att
      private int orderLineId;
    private int quantity;
    private double lineTotal;
    private Product product;
    
    //Getters setters
    public int getOrderLineId() {
        return orderLineId;
    }

    public void setOrderLineId(int orderLineId) {
        this.orderLineId = orderLineId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getLineTotal() {
        return lineTotal;
    }

    public void setLineTotal(double lineTotal) {
        this.lineTotal = lineTotal;
    }
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
    
    //Con
    
    public OrderLine(Order order, Product product)
    {
        this.orderLineId = order.createNewOrderLineId();
        this.product = product;
        this.quantity = 0;
        this.lineTotal = 0;
                
    }
    
    
     
      public OrderLine(int orderLineId, Product product, int quantity, double lineTotal)
    {
        this.orderLineId = orderLineId;
        this.product = product;
        this.quantity = quantity;
        this.lineTotal = lineTotal;
                
    }
     
     public OrderLine(Order order, int quantity, Product product)
     {
        this.orderLineId = order.createNewOrderLineId();
        this.product = product;
        this.quantity = quantity;
        lineTotal = product.getPrice()* quantity;
     }
     
    public OrderLine(Order order, Product product, int quantity, double lineTotal)
    {
        this.orderLineId = order.createNewOrderLineId();
        this.product = product;
        this.quantity = quantity;
        this.lineTotal = lineTotal;
    }
            
}
