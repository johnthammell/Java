/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author John Hammell
 */
public class Staff extends User {
     //Private attributes
    private String Position;
    
    //Getters and setters
    
     /**
     * @return the Position
     */
    public String getPosition() {
        return Position;
    }

    /**
     * @param Position the Position to set
     */
    public void setPosition(String Position) {
        this.Position = Position;
    }

    
    //con
    public Staff()
    {
        super();
    }
    
    public Staff(double salary, String position, String username, String password, String firstName, String lastName, String role, String email)
    {
        //Super methods gets attributes from superclass
        super(username, password, firstName, lastName, role, email);
        
    }
    
    public String displayGreeting()
    {
        
        return "<html> Welcome " + getFirstName() +" "+ getLastName() + 
                "<br>  You can enter the staff page by clicking the button at the bottom of the page</html>";
    }

  
}
