/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import Database.DbOrder;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author John Hammell
 */
public class Customer extends User{
      
    //Private attributes
    private String addressLine1;
    private String addressLine2;
    private String town;
    private String postcode;
    private boolean isRegistered;
    private HashMap<Integer, Order> orders;
    
    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }
     public boolean getIsRegistered() {
        return isRegistered;
    }

    public void setIsRegistered(boolean isRegistered) {
        this.isRegistered = isRegistered;
    }
    public HashMap<Integer, Order> getOrders() {
        return orders;
    }

    public void setOrders(HashMap<Integer, Order> orders) {
        this.orders = orders;
    }
    
    
    //Constructors
    public Customer()
    {
        super();
        this.addressLine1 = "";
        this.addressLine2 = "";
        this.town = "";
        this.postcode = "";
        this.isRegistered = false;
        this.orders = new HashMap<>();
    }
   
    
    //Overloaded constuctor with inheritence
    public Customer(String addressLine1, String addressLine2, String town, String postcode,
            String username, String password, String firstName, String lastName, boolean isRegistered, String role, String email)
    {
        super(username, password, firstName, lastName, role, email);
        this.addressLine1 =addressLine1;
        this.addressLine2 = addressLine2;
        this.town = town;
        this.postcode = postcode;
        this.isRegistered = isRegistered;
        this.orders = new HashMap<>();
    }
    
    //Will display the cust name after logging in 
    public String displayGreeting()
    {
        if(getRole().equals("Customer"))
        {
            return "<html> Welcome " + getFirstName() +" "+ getLastName() + "<br> Click on one of the categories to begin shopping</html>";
        }
        else
        {
            return "<html> Welcome " + getFirstName() +" "+ getLastName() + "<br> Your account has been suspended, <br> Please contact a member of staff.</html>";
        }
    }
    
    public Order findLatestOrder()
    {
        //decalre an order
        Order latestOrder = new Order(this);
        
        //check if order exist
        if(getOrders().isEmpty())
        {
            //blank order is now the latest order
            //add it to hashmap
            addOrder(latestOrder);
                    
        }
         else
        {
            //The Customer has made atleast one order before
            
            //fetch the first order in the hashmap
            latestOrder = getOrders().get(getOrders().keySet().toArray()[0]);
            
            //loop round all items
            for(Map.Entry<Integer, Order> oEntry : getOrders().entrySet())
            {
                //map the current hashmap entry to an order
                Order current = oEntry.getValue();
                //If current order date is larger than  what we have then replace the current order with what we have
                if(current.getOrderDate().after(latestOrder.getOrderDate()))
                {
                    //replace latest order with this values
                    latestOrder = current;
                }
            }
            //Nw we have the latest order
            //Check its status to see if complete
            if(latestOrder.getStatus().equalsIgnoreCase("Complete"))
            {
                //Revert latest back to new order
                
                latestOrder = new Order(this);
                addOrder(latestOrder);
            }
            
        }
        //return latest order
            
            return latestOrder;
    }
    
    public void addOrder(Order o)
    {
        //add the order to the database
        DbOrder db = new DbOrder();
        //addOrder returns the primary key that was assigned to the order
        int orderId = db.addOrder(this.getUsername(), o);
        
        //update the order to have the REAL order id before storing in hashmap
        o.setOrderId(orderId);
        
        //add the order to the hashmap
        orders.put(o.getOrderId(), o);
    }
    
    public int generateUniqueOrderId()
    {
    //start order id at 1
        int orderId = 1;
        
        //Loop while order id exists
        while(getOrders().containsKey(orderId))
        {
            //Add one to the id
            orderId++;
        }

        //return id

        return orderId;
        
    }
    
}
