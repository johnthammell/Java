/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author John Hammell
 */
public class Product {
    //Private attributes
    private int productId;
    private String productName;
    private double price;
    private int stockLevel;
    
    
    //Getters and setters
     public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStockLevel() {
        return stockLevel;
    }

    public void setStockLevel(int stockLevel) {
        this.stockLevel = stockLevel;
    }
    
    //0Param constructor
    public Product()
    {
        this.productId = 0;
        this.productName = "";
        this.price = 0.00;
        this.stockLevel = 0;
    }
    
    //overloaded constructor
    public Product(int productId, String productName, double price, int stockLevel)
    {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.stockLevel = stockLevel;
    }
    
    public Product( String productName, double price, int stockLevel)
    {
        
        this.productName = productName;
        this.price = price;
        this.stockLevel = stockLevel;
    }
    
    //override the current implementation of ToString function
    //this is POLYMORPHISM!
    @Override
    public String toString()
    {
        //return a value that combines the name of the product and their type
       
        return (productName + String.valueOf(price));
    }
}
