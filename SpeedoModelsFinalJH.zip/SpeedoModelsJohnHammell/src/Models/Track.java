/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author John Hammell
 */
public class Track extends Product{
    
    private String trackSize;

    /**
     * @return the trackSize
     */
    public String getTrackSize() {
        return trackSize;
    }

    /**
     * @param trackSize the trackSize to set
     */
    public void setTrackSize(String trackSize) {
        this.trackSize = trackSize;
    }
    
    //Constructors
    public Track(String trackSize)
    {
        this.trackSize = trackSize;
    }

    public Track(String trackSize, int productId, String productName, double price, int stockLevel) 
    {
        super(productId, productName, price, stockLevel);
        this.trackSize = trackSize;
    }

    public Track(String trackSize, String productName, double price, int stockLevel) 
    {
        super(productName, price, stockLevel);
        this.trackSize = trackSize;
    }
    
    //override the current implementation of ToString function
    //this is POLYMORPHISM!
    @Override
    public String toString()
    {
        //return a value that combines the name of the product and their type
       
        return (super.getProductName() + " Track Size: "+ trackSize + " £" + String.valueOf(super.getPrice()));
    }
    
}
