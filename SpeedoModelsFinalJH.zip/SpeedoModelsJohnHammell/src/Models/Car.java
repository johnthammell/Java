/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author John Hammell
 */
public class Car extends Product{
    private String carColour;

    /**
     * @return the carColour
     */
    public String getCarColour() {
        return carColour;
    }

    /**
     * @param carColour the carColour to set
     */
    public void setCarColour(String carColour) {
        this.carColour = carColour;
    }

    
    //Constructors
    public Car(String carColour) {
        this.carColour = carColour;
    }

    public Car(String carColour, int productId, String productName, double price, int stockLevel) {
        super(productId, productName, price, stockLevel);
        this.carColour = carColour;
    }

    public Car(String carColour, String productName, double price, int stockLevel) {
        super(productName, price, stockLevel);
        this.carColour = carColour;
    }
    
    //override the current implementation of ToString function
    //this is POLYMORPHISM!
    @Override
    public String toString()
    {
        //return a value that combines the name of the product and their type
       
        return (super.getProductName() + " Colour: "+ carColour +" £" + String.valueOf(super.getPrice()));
    }
    
}
