/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import Database.DbProduct;
import Database.DbUser;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author John Hammell
 */
//This class will create a pdf file
public class PDFHandler {
    
   
    Document document = new Document();
    HashMap<String, Customer> allCustomers = new HashMap<>();
    HashMap<Integer, Product> allProducts = new HashMap<>();
    
    public void exportUsers()
    {
        //All cutomers are loaded so that the customers vaules can be added to the pdf
        DbUser db = new DbUser();
        allCustomers = db.loadAllCustomers();
        Paragraph p = new Paragraph();
        
        //loop round every customer
        //FOR each customer a block of text with the cust details is added to the pdf
        
        for (Map.Entry<String, Customer> c : allCustomers.entrySet())
        {
          Customer currentCustomer = c.getValue();
          p.add(new Paragraph(currentCustomer.getUsername()));
          p.add(new Paragraph(currentCustomer.getEmail()));
          p.add(new Paragraph(currentCustomer.getFirstName()));
          p.add(new Paragraph(currentCustomer.getLastName()));
          p.add(new Paragraph(currentCustomer.getAddressLine1()));
          p.add(new Paragraph(currentCustomer.getAddressLine2()));
          p.add(new Paragraph(currentCustomer.getTown()));
          p.add(new Paragraph(currentCustomer.getPostcode()));
          p.add(new Paragraph(currentCustomer.getRole()));
          addEmptyLine(p, 1);
        }
        
        
        try
        {
            //Choose where the pdf will be saved
            //add the text that was added above
            
            PdfWriter.getInstance(document, new FileOutputStream("D:\\Graded Unit\\SpeedoModelsJohnHammell\\pdf\\users.pdf"));
            document.open();
            document.add(p);
            document.close();
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        
         
    }
    
    public void exportProducts()
    {
        //All products are loaded so that the customers vaules can be added to the pdf
        DbProduct db = new DbProduct();
        allProducts = db.loadAllProducts();
        Paragraph p = new Paragraph();
        
        //loop round every customer
        //FOR each customer a block of text with the cust details is added to the pdf
        for (Map.Entry<Integer, Product> prod : allProducts.entrySet())
        {
            Product currentProduct = prod.getValue();
            p.add(new Paragraph(String.valueOf(currentProduct.getProductId())));
           p.add(new Paragraph(currentProduct.getProductName()));
          addEmptyLine(p, 1);
        }
        
        
        try
        {
            //Choose where the pdf will be saved
            //add the text that was added above
            
            PdfWriter.getInstance(document, new FileOutputStream("D:\\Graded Unit\\SpeedoModelsJohnHammell\\pdf\\products.pdf"));
            document.open();
            document.add(p);
            document.close();
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        
         
    }
    
    //This will add a line to better destinguish different items 
    private static void addEmptyLine(Paragraph paragraph, int number) {
        for (int i = 0; i < number; i++) {
            paragraph.add(new Paragraph("---"));
        }
    }
    
}
