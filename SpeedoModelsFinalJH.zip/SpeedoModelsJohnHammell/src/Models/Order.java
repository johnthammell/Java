/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import Database.DbOrder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author John Hammell
 */
public class Order {
    
    //Private att
    private int orderId;
    private Date orderDate;
    private double orderTotal;
    private String status;
    private HashMap<Integer, OrderLine> orderLines;
    private Customer customer;
    
    //Getters and setters
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public double getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(double orderTotal) {
        this.orderTotal = orderTotal;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public HashMap<Integer, OrderLine> getOrderLines() {
        return orderLines;
    }

    public void setOrderLines(HashMap<Integer, OrderLine> orderLines) {
        this.orderLines = orderLines;
    }
    
     public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    
    public Order(Customer currentCustomer)
    {
        this.orderId = currentCustomer.generateUniqueOrderId();
        this.customer = currentCustomer;
        this.orderDate = new Date();
        this.orderTotal = 0;
        this.status = "new";
        this.orderLines = new HashMap<>();
    }
    
    //constructors
    
    
    
    public Order(int orderId, Date orderDate, double orderTotal, String status, Customer cust)
    {
        this.customer = cust;
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.orderTotal = orderTotal;
        this.status = status;
        this.orderLines = new HashMap<>();
    }
    
    
    
    //beh
    
    public void addOrderLine(OrderLine oLine)
    {
        //Add orderline to the database as well
        DbOrder db = new DbOrder();
        db.addOrderLine(orderId, oLine);
        
        //the kry is the orderline id
        orderLines.put(oLine.getOrderLineId(), oLine);
        
        orderTotal = orderTotal + oLine.getLineTotal();
    }
    
    public void removeOrderLine(int productId)
    {
        //Make a copy of the hashmap to loop through
       HashMap<Integer, OrderLine> loopingSet = new HashMap<>(); 
       loopingSet.putAll(orderLines);
       
       //Loop through all items in the hashmap
        for(Map.Entry<Integer, OrderLine> oEntry : loopingSet.entrySet())
        {
            //Map the current value to the orderLine
            OrderLine oLine = oEntry.getValue();
            
            //check if each instance in the loop matches the order we want to remove
            if(oLine.getProduct().getProductId()== productId)
            {
                //if match then remove
               
                DbOrder db = new DbOrder();
                db.deleteOrderLine(orderId, oLine);
                //Then REMOVE from REAL hashmap
                orderLines.remove(oLine.getOrderLineId());
                
                //decrease the ordertotal
                orderTotal = orderTotal - oLine.getLineTotal();
                
            }
    }
    }
    public int createNewOrderLineId()
    {
        //start our line id at 1
        int newId = 1;
        
        //loop round every order line till we get to a num that doesnt exist
        
        while(orderLines.containsKey(newId))
        {
            //Add one to the id
            newId++;
        }

        //return id

        return newId;
    }
}
