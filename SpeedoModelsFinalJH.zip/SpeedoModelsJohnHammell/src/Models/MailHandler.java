/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author John Hammell
 */

//This class will send users emails 
public class MailHandler {
    
    public void sendEmail(Customer cust)
    {
         try{
            //This part 
            String host ="smtp.gmail.com" ;
            String user = "speedomodelsJH2@gmail.com";
            String pass = "gradedunit123";
            String to = cust.getEmail();
            String from = "speedomodelsJH@gmail.com";
            
            //This will contain the subject and the text content
            String subject = "Order confirmation";
            String txtBody = "Thank you for your order " + cust.getFirstName() + " " + cust.getLastName() + " Your order number is " + cust.findLatestOrder().getOrderId();
            boolean sessionDebug = false;

            Properties props = System.getProperties();

            //Host details
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", host);
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.required", "true");

            java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
            Session mailSession = Session.getDefaultInstance(props, null);
            mailSession.setDebug(sessionDebug);
            Message msg = new MimeMessage(mailSession);
            msg.setFrom(new InternetAddress(from));
            InternetAddress[] address = {new InternetAddress(to)};
            msg.setRecipients(Message.RecipientType.TO, address); 
            msg.setSubject(subject); 
            msg.setSentDate(new Date()); 
            
            //Create the email
            Multipart emailContent = new MimeMultipart();
            
            //sets the text of the email to the string txtBody
            MimeBodyPart textBodyPart = new MimeBodyPart();
            textBodyPart.setText(txtBody); //Mail body
            
            
            //attatchmentPart
            //Currently no attatchment s are sent but the system should have a way of doing it for future versions 
            //MimeBodyPart attatchmentBodyPart = new MimeBodyPart();
            //attatchmentBodyPart.attachFile("D:\\Graded Unit\\SpeedoModelsJohnHammell\\src\\img\\car.png");
            
            //Add parts to content
            emailContent.addBodyPart(textBodyPart);
            //emailContent.addBodyPart(attatchmentBodyPart);
            
            //Load content to be sent
            msg.setContent(emailContent);
            
           Transport transport=mailSession.getTransport("smtp");
           transport.connect(host, user, pass);
           transport.sendMessage(msg, msg.getAllRecipients());
           transport.close();
           
           //Confirmation
           System.out.println("email sent successfully"); 
           
        }catch(Exception ex)
        {
            System.out.println(ex);
        }
    }
    
    
}
