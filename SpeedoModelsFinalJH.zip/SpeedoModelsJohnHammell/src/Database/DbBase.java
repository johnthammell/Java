/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author John Hammell
 */
public class DbBase {
       //Final string for the location of the DB
    private final String dbLocation = "jdbc:ucanaccess://Data\\ShopDB.accdb";
    
    /**
     * @return the dbLocation
     */
    public String getDbLocation() {
        return dbLocation;
    }
    
    //a function which returns a connection
    public Connection setupConnection()
    {
        try
        {
            //uCanAccess uses the JDBC built in DriverManager class to communicate with the database
            //call the Class.forName method to load the uCanAccess instance into the DriverManager class
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            //get a connection to the database in the location specified
            Connection conn = DriverManager.getConnection(getDbLocation());
            
            //return the connection
            return conn;
        }
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            //return a null connection if an exception was raised
            return null;
        }
    }

    
}
