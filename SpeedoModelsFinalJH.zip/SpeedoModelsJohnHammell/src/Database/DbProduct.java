/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import Models.Car;
import Models.Product;
import Models.Track;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;

/**
 *
 * @author John Hammell
 */
public class DbProduct extends DbBase {
    public HashMap<Integer, Product> loadAllProducts()
    {
        
        //Declare hashmap
        HashMap<Integer, Product> allProducts = new HashMap<>();
        
        Connection conn = null; 
        
        try
        {
                //Load db connection
        //You can access uses the built in DriverManager to communicate with the db
        //Calling the class forname to lead ucanaccess into the drivermanager
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        conn = DriverManager.getConnection(super.getDbLocation());
        
        //Query new cust
        String sql = "SELECT * FROM Products";
        Statement stmt = conn.createStatement();  
        
        ResultSet rs = stmt.executeQuery(sql);
        
        //Get the ralues from the db
        while(rs.next())
        {
           int productId = rs.getInt("ProductId");
           String productName = rs.getString("ProductName");
           double price = rs.getDouble("Price");
           int stockLevel = rs.getInt("StockLevel");
           String carColour = rs.getString("CarColour");
           String size = rs.getString("TrackSize");
           
           if(carColour != null)
           {
               Car c = new Car(carColour, productId, productName, price, stockLevel);
               allProducts.put(productId, c);
           }
           else
           {
               Track t = new Track(size,productId, productName, price, stockLevel);
               allProducts.put(productId, t);
           }
           
        }
        }
        catch(Exception ex)
        {
                        //print exception
            System.out.println("DBError - " + ex.getMessage());
        }
        finally
        {
            return allProducts;
        }
    }
    
    //a function which will add an product to the db
    //triggered from staff product menu
    public int addProduct(Product newProduct)
    {
        
        String carColour = "NULL";
        String trackSize = "NULL";
        
        //determine which type of product it is
        if(newProduct.getClass().getSimpleName().equalsIgnoreCase("Car"))
        {
            //It's a car so get the colour value out of the object
            Car newCar = (Car)newProduct;
            carColour = "'" + newCar.getCarColour() + "'";
        }
        else
        {
            //It's a track so get the tracksize value out of the object
            Track newTrack = (Track)newProduct;
            trackSize = String.valueOf(newTrack.getTrackSize());
        }
        
        //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        {                   
            //create an SQL statement to execute against the database
            String sql = "INSERT INTO  Products (ProductId, ProductName, TrackSize, CarColour, Price, StockLevel) " +
                    "VALUES " +
                    "('" + 
                    newProduct.getProductId() + "', '" + 
                    newProduct.getProductName() + "', '" + 
                    trackSize + "', " + 
                    carColour + ", " + 
                    newProduct.getPrice() + ", " + 
                    newProduct.getStockLevel() + 
                    ")";
            
            Statement stmt = conn.createStatement();   
            //call executeUpdate which either INSERTS UPDATES or DELETES depending on SQL command
            int rowsAffected = stmt.executeUpdate(sql);
            
            return rowsAffected;
        }
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            return 0;
        }
    }
    
     //a method which will edit an product to the db
    //triggered from admin product menu
    public int updateProduct(Product newProduct)
    {
        
        String carColour = "NULL";
        String trackSize = "NULL";
        
        //determine which type of product it is
        if(newProduct.getClass().getSimpleName().equalsIgnoreCase("Car"))
        {
            //It's a carso get the waterType value out of the object
            Car newCar = (Car)newProduct;
            carColour = "'" + newCar.getCarColour() + "'";
        }
        else
        {
            //It's a track so get the CanFly value out of the object
            Track newTrack = (Track)newProduct;
            trackSize = String.valueOf(newTrack.getTrackSize());
        }
        
        //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        {             
            //create an SQL statement to execute against the database
            String sql = "UPDATE Products SET " +
                    
                    "ProductName = '" + newProduct.getProductName() + "', " + 
                    "Price = '" + newProduct.getPrice() + "', " +
                    "StockLevel = '" + newProduct.getStockLevel() + "', " +
                    "CarColour = " + carColour + ", " +
                    "TrackSize = '" + trackSize +  "' " +
                    "WHERE ProductId = '" + newProduct.getProductId() + "'";
            
            Statement stmt = conn.createStatement();   
            //call executeUpdate which either INSERTS UPDATES or DELETES depending on SQL command
            int rowsAffected = stmt.executeUpdate(sql);  
            
            return rowsAffected;
        }
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            return 0;
        }
    }
    
    //a method which will delete an product to the db
    //triggered from staff product menu
    public int deleteProduct(Product product)
    {
        //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        { 
            //create an SQL statement to execute against the database
            String sql = "DELETE FROM Products WHERE ProductId = '" + product.getProductId() + "'";
            
            Statement stmt = conn.createStatement();   
            //call executeUpdate which either INSERTS UPDATES or DELETES depending on SQL command
            int rowsAffected = stmt.executeUpdate(sql);
                      
            return rowsAffected;
        }
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            return 0;
        }
    }
    
    
}
