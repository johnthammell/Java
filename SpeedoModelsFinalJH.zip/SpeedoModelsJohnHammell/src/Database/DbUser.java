/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import Models.Customer;
import Models.Staff;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;

/**
 *
 * @author John Hammell
 */
public class DbUser extends DbBase {
    
    
    //Method will return a role of the user, Used for validating privilages
    public String checkRole(String username, String password)
    {
          //call loadallCustomers
        
        HashMap<String, Customer> customers = loadAllCustomers();
        
        HashMap<String, Staff> staff = loadAllStaff();
        
        //check to see if admin contains email passed as param
        if(customers.containsKey(username))
        {
            //if true, get ful record
            Customer c = customers.get(username);
            
            //check the password matches
            
            if(c.getPassword().equals(password))
            {
                //then return users role
                
                return c.getRole();
                
            }
            
        }
        if(staff.containsKey(username))
        {
            //if true, get ful record
            Staff s = staff.get(username);
            
            //check the password matches
            
            if(s.getPassword().equals(password))
            {
                //then return users role
                
                return s.getRole();
                
            }
            
        }
         //if we get here wither the emial or password is incorrect
        //return a null value
        
        return null;
         
    }
    
    public HashMap<String, Customer> loadAllCustomers()
    {
        //Declare hashmap
        HashMap<String, Customer> allCustomers = new HashMap<>();
        
        Connection conn = null; 
        
        try
        {
           //Load db connection
        //You can access uses the built in DriverManager to communicate with the db
        //Calling the class forname to lead ucanaccess into the drivermanager
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        conn = DriverManager.getConnection(super.getDbLocation());
        
        //Query new products
        String sql = "SELECT * FROM Customers";
        Statement stmt = conn.createStatement();  
        
        ResultSet rs = stmt.executeQuery(sql);
        
        while(rs.next())
        {
            String username = rs.getString("Username");
            String password = rs.getString("Password");
            String firstName = rs.getString("FirstName");
            String lastName = rs.getString("LastName");
            String addressLine1 = rs.getString("AddressLine1");
            String addressLine2 = rs.getString("AddressLine2");
            String town = rs.getString("Town");
            String postcode = rs.getString("Postcode");
            String role = rs.getString("Role");
            String email = rs.getString("Email");
            
            Customer cust = new Customer();
            cust.setIsRegistered(true);
            Customer c = new Customer(addressLine1, addressLine2, town, postcode, username, password, firstName, lastName, cust.getIsRegistered(), role, email);
            
            //add to hashmap
            allCustomers.put(username, c);
            
            
            
        }
        
        
        }
        catch(Exception ex)
        {
                      //print exception
            System.out.println("DBError - " + ex.getMessage());
        }
        finally
        {
            //before returning ensure all order and orderlines are loaded
            DbOrder db = new DbOrder();
            allCustomers = db.loadOrders(allCustomers);
            allCustomers = db.loadOrderLines(allCustomers);
            
            return allCustomers;
        }
        
        
    }
    
    //This function will return a specific user if the user and pass are correct
    public Customer customerLogin(String username, String password)
    {
        //call loadallCustomers
        
        HashMap<String, Customer> customers = loadAllCustomers();
        
        //check to see if admin contains email passed as param
        if(customers.containsKey(username))
        {
            //if true, get ful record
            Customer c = customers.get(username);
            
            //check the password matches
            
            if(c.getPassword().equals(password))
            {
                //then return user to the calling code
                return c;
            }
            
        }
         //if we get here wither the emial or password is incorrect
        //return a null value
        
        return null;
         
         
    }
    
    public Customer findUser(String username)
    {
        //call loadallCustomers
        
        HashMap<String, Customer> customers = loadAllCustomers();
        
        if(customers.containsKey(username))
        {
            //if true, get ful record
            Customer c = customers.get(username);
            
         
            
                //then return user to the calling code
                return c;
           
            
        }
         //if we get here wither the emial or password is incorrect
        //return a null value
        
        return null;
    }
    
    //This function will load all staff from the db
    public HashMap<String, Staff> loadAllStaff()
    {
        //Declare hashmap
        HashMap<String, Staff> allStaff = new HashMap<>();
        
        Connection conn = null;   
        
         try
        {
          //Load db connection
        //You can access uses the built in DriverManager to communicate with the db
        //Calling the class forname to lead ucanaccess into the drivermanager
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        conn = DriverManager.getConnection(super.getDbLocation());
        
        //Query new products
        String sql = "SELECT * FROM Staff";
        Statement stmt = conn.createStatement();
        
        ResultSet rs = stmt.executeQuery(sql);
        
        while(rs.next())
        {
            String username = rs.getString("Username");
            String password = rs.getString("Password");
            String firstName = rs.getString("FirstName");
            String lastName = rs.getString("LastName");
            String position = rs.getString("Position");
            double salary = rs.getDouble("Salary");
            String role = rs.getString("Role");
            String email = rs.getString("Email");
           
            Staff s = new Staff(salary, position, username, password, firstName, lastName, role, email);
            allStaff.put(username, s);
            
        }
        
        
        }
         catch(Exception ex)
         {
                      //print exception
            System.out.println("DBError - " + ex.getMessage());
         }
         finally
         {
             return allStaff;
         }
         
    
    }
    
    
    //This function will return a specific user if the user and pass are correct
    public Staff staffLogin(String username, String password)
    {
        //call loadallstaff
        
        HashMap<String, Staff> staff = loadAllStaff();
        
        //check to see if admin contains email passed as param
        if(staff.containsKey(username))
        {
            //if true, get ful record
            Staff s = staff.get(username);
            
            //check the password matches
            
            if(s.getPassword().equals(password))
            {
                //then return user to the calling code
                return s;
            }
            
        }
         //if we get here wither the emial or password is incorrect
        //return a null value
        
        return null;
         
         
    }
    //a function which adds a customer to the database
    //this will be triggered from the Registration form
    public int registerCustomer(Customer newCust)
    {
        //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        {             
            //create an SQL statement to execute against the database
            String sql = "INSERT INTO Customers (Username, Password, FirstName, LastName, AddressLine1, AddressLine2, Town, Postcode, Role, Email)" +
                    "VALUES " +
                    "('" + 
                    newCust.getUsername() + "', '" + 
                    newCust.getPassword()+ "', '" + 
                    newCust.getFirstName() + "', '" + 
                    newCust.getLastName() + "', '" + 
                    //new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(newCust.getDateHired()) + "', '" + 
                    newCust.getAddressLine1() + "', '" + 
                    newCust.getAddressLine2() + "', '" + 
                    newCust.getTown()+ "', '" +
                    newCust.getPostcode()+ "', '" +
                    newCust.getRole()+ "', '" +
                    newCust.getEmail()+ 
                    "')";
            
            Statement stmt = conn.createStatement();  
            //call executeUpdate which either INSERTS UPDATES or DELETES depending on SQL command
            int rowsAffected = stmt.executeUpdate(sql);
            
            return rowsAffected;
        }
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            return 0;
        }
    }
    
    //a method which updates the custs personal details
    //this will be triggered from cust edit details form
    public int updateCustomer(Customer newCustomer)
    {
        //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        {             
            //create an SQL statement to execute against the database
            String sql = "UPDATE Customers SET " +
                    
                    "Password = '" + newCustomer.getPassword() + "', " + 
                    "FirstName = '" + newCustomer.getFirstName() + "', " +
                    "LastName = '" + newCustomer.getLastName() + "', " +
                    "AddressLine1 = '" + newCustomer.getAddressLine1() + "', " + 
                    "AddressLine2 = '" + newCustomer.getAddressLine2() + "', " +
                    "Town = '" + newCustomer.getTown() + "', " + 
                    "Postcode = '" + newCustomer.getPostcode() + "', " + 
                    "Role = '" + newCustomer.getRole() + "', " + 
                    "Email = '" + newCustomer.getEmail() + "' " + 
                    "WHERE Username = '" + newCustomer.getUsername() + "'";
            
            Statement stmt = conn.createStatement();   
            //call executeUpdate which either INSERTS UPDATES or DELETES depending on SQL command
            int rowsAffected = stmt.executeUpdate(sql); 
            
            return rowsAffected;
        }
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            return 0;
        }
    }
    
    
    //a method which updates the custoemrs personal details
    //this will be triggered from unregister button on customer home
    public int deleteCustomer(Customer cust)
    {
        //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        { 
            //create an SQL statement to execute against the database
            String sql = "DELETE FROM Customers WHERE Username = '" + cust.getUsername() + "'";
            
            Statement stmt = conn.createStatement();   
            //call executeUpdate which either INSERTS UPDATES or DELETES depending on SQL command
            int rowsAffected = stmt.executeUpdate(sql); 
            
            return rowsAffected;
        }
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            return 0;
        }
    }
    
}
