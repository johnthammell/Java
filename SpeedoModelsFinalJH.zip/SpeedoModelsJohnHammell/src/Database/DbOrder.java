/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import Models.Customer;
import Models.Order;
import Models.OrderLine;
import Models.Product;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author John Hammell
 */
public class DbOrder extends DbBase {
    public HashMap<String, Customer> loadOrders(HashMap<String, Customer> custs)
    {
        //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        { 
            //create an SQL statement to execute against the database
            String sql = "SELECT * FROM Orders";
            
            Statement stmt = conn.createStatement();   
            
            //execute the query and save the resultSet
            ResultSet rs = stmt.executeQuery(sql);
            
            //loop round each returned ordered
            while(rs.next())
            {
                //load the data into an order object
                int orderId = rs.getInt("OrderId");
                Date orderDate = rs.getDate("OrderDate");
                String username = rs.getString("Username");
                double orderTotal = rs.getDouble("OrderTotal");
                String status = rs.getString("Status");
                
                //make sure the order is for a current customer
                //if not - do not try to load it
                if (custs.containsKey(username))
                {
                    //get the customer who made the order
                    Customer customer = custs.get(username);
                    
                    //create an instance of the order using above data
                    Order o = new Order(orderId, orderDate,  orderTotal, status, customer);
                    
                    //add the order to the customer we found  
                    customer.getOrders().put(orderId, o);                    
                }
                
            }            
        }
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
        }
        finally
        {
            //return the fully populated orders and customers
            return custs;
        }
    }
    
    
    public HashMap<String, Customer> loadOrderLines(HashMap<String, Customer> customers)
    {
        //load a hashmap of all products
        DbProduct db = new DbProduct();
        HashMap<Integer, Product> products = db.loadAllProducts();
        
        //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        { 
            //create an SQL statement to execute against the database
            String sql = "SELECT * FROM OrderLines";
            
            Statement stmt = conn.createStatement();   
            
            //execute the query and save the resultSet
            ResultSet rs = stmt.executeQuery(sql);
            
            //loop round each returned ordered
            while(rs.next())
            {
                //load all data into an orderline object
                int orderLineId = rs.getInt("OrderLineId");
                int productID = rs.getInt("ProductID");
                int quantity = rs.getInt("Quantity");
                double lineTotal = rs.getDouble("LineTotal");
                int orderId = rs.getInt("OrderId");
                
                //find the product that matches this product Id
                Product p = products.get(productID);
                
                //loop round each Customer in the hashmap
                for(Map.Entry<String, Customer> entry : customers.entrySet())
                {
                    //get the customer from this entry
                    Customer c = entry.getValue();
                    
                    //see if that customer made the order that this orderline is for
                    if (c.getOrders().containsKey(orderId))
                    {
                        //if so - create an instance of the orderline class
                        OrderLine ol = new OrderLine(orderLineId, p, quantity, lineTotal);
                        
                        //add this orderline to the correct order for that customer
                        c.getOrders().get(orderId).getOrderLines().put(orderLineId, ol);
                        //the above line effectively does this:
                        //get orders
                        //find exact order
                        //get exact order orderlines
                        //add new orderline to this list
                    }
                }
            }
        }
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
        }
        finally
        {
            //return the fully populated orders and customers
            return customers;
        }
    }
    
    //a function that wull add an order and hten return the orderId
     public int addOrder(String username, Order o)
     {
         
         int orderId = 0;
         
         
          //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        { 
            //create an SQL statement to execute against the database
            String sql = "INSERT INTO Orders (OrderDate, Username, OrderTotal, Status) " + 
                    "VALUES " + 
                    "('" +
                    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(o.getOrderDate()) + "', '" +
                    username + "', '" +
                    o.getOrderTotal() + "', '" +
                    o.getStatus() + 
                    "')";
            
            Statement stmt = conn.createStatement();   
            
            stmt.executeUpdate(sql);
            
            //
            ResultSet rs = stmt.getGeneratedKeys();
            
            //loop around each return ordered
            while(rs.next())
            {
                //Get order id
                orderId = rs.getInt(1);
                
            }
            
        }
        
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            
        }
        finally
        {
            //return the generated primary key
            return orderId;
            
        }
     }
       //a method which updates the total of the order 
    public void updateOrderTotal(int orderId, double lineTotal)
    {
        
         try (Connection conn = setupConnection())
        { 
            //create an SQL statement to execute against the database
            String sql = "UPDATE Orders " +
                    "SET " + 
                    "OrderTotal = OrderTotal + " + lineTotal + " " +
                     "WHERE OrderId = " + orderId;
            
            Statement stmt = conn.createStatement();   
            
            stmt.executeUpdate(sql);
            
            //
            
            
           
        }
         catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            
        }
        
    }
    
    public void addOrderLine(int orderId, OrderLine ol)
     {
         
         
         
         
          //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        { 
            //create an SQL statement to execute against the database
            String sql = "INSERT INTO OrderLines (OrderLineId, ProductId, Quantity, LineTotal, OrderId) " + 
                    "VALUES " + 
                    "('" +
                    ol.getOrderLineId() + "', '" +
                    ol.getProduct().getProductId() + "', '" +
                    ol.getQuantity() + "', '" +
                    ol.getLineTotal() + "', '" +
                    orderId +
                    "')";
            
            Statement stmt = conn.createStatement();   
            
            stmt.executeUpdate(sql);
            
            //Update the order total to reflect this order total
            updateOrderTotal(orderId, ol.getLineTotal());
            
            
        }
        
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            
        }
        
     }
    
     public void deleteOrderLine(int orderId, OrderLine ol)
     {
         
         
         
         
          //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        { 
            //create an SQL statement to execute against the database
            String sql = "DELETE FROM OrderLines " + 
                    "WHERE ProductId = " + ol.getProduct().getProductId() + " " +
                    "AND OrderId = " + orderId;
                    
                    
            
            Statement stmt = conn.createStatement();   
            
            //Call the delete statement
            stmt.executeUpdate(sql);
            
            //Update the order total to reflect deleting this order total
            updateOrderTotal(orderId, -ol.getLineTotal());
            
            
        }
        
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            
        }
        
     }
     
      public void updateStock(Product p, int quantity)
     {
 
         //quantity = p.getStockLevel() - quantity;
         
          //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        { 
            //create an SQL statement to execute against the database
            String sql = "UPDATE Products " + 
                    "SET StockLevel = "+ p.getStockLevel() + " " +
                    "WHERE ProductID = " + p.getProductId();
                    
                    
            
            Statement stmt = conn.createStatement();   
            
            //Call the delete statement
            stmt.executeUpdate(sql);
          
                        
        }
        
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            
        }
        
     }
      
      public void completeOrder(int orderId)
     {
 
          //using try-with-resources in Java means the connection object is automatically closed at the end
        try (Connection conn = setupConnection())
        { 
            //create an SQL statement to execute against the database
            String sql = "UPDATE Orders " + 
                    "SET Status= 'Complete', " +
                    "OrderDate = '" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + "' " +
                    "WHERE OrderID = " + orderId;
                    
                    
            
            Statement stmt = conn.createStatement();   
            
            //Call the update statement
            stmt.executeUpdate(sql);
          
                        
        }
        
        catch(Exception ex)
        {
            String message = ex.getMessage();
            System.out.println(message);
            
            
        }
        
     }
    
}
